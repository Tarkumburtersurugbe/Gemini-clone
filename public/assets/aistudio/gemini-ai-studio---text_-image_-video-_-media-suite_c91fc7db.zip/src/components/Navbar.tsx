import React, { useState } from 'react';
import {
  Sparkles,
  MessageSquare,
  Image as ImageIcon,
  Video,
  Mic,
  Sliders,
  Menu,
  CheckCircle2,
  ChevronDown,
  Trash2,
  LogOut,
  Home,
  User,
} from 'lucide-react';
import { StudioMode, UserProfile } from '../types';

interface NavbarProps {
  currentMode: StudioMode;
  onSelectMode: (mode: StudioMode) => void;
  selectedModel: string;
  onSelectModel: (model: string) => void;
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
  currentUser: UserProfile | null;
  onOpenSignIn: () => void;
  onSignOut: () => void;
  onOpenDeleteHistory: () => void;
  onGoToLanding: () => void;
}

const AVAILABLE_MODELS = [
  { id: 'gemini-3.5-flash-lite', name: 'Gemini 3.5 Flash Lite', tag: 'Free Tier · High Throughput (Active)' },
  { id: 'gemini-flash-lite-latest', name: 'Gemini Flash Lite', tag: 'Free Tier · Low Latency (Active)' },
  { id: 'gemini-3.5-flash', name: 'Gemini 3.5 Flash', tag: 'Free Tier · Multimodal' },
];

export function Navbar({
  currentMode,
  onSelectMode,
  selectedModel,
  onSelectModel,
  onToggleSidebar,
  currentUser,
  onOpenSignIn,
  onSignOut,
  onOpenDeleteHistory,
  onGoToLanding,
}: NavbarProps) {
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const modes: { id: StudioMode; label: string; icon: React.ReactNode }[] = [
    { id: 'chat', label: 'Chat & Multimodal', icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'imagen', label: 'Imagen Studio', icon: <ImageIcon className="w-4 h-4" /> },
    { id: 'video', label: 'Video Lab & Inspector', icon: <Video className="w-4 h-4" /> },
    { id: 'audio', label: 'Voice & Audio', icon: <Mic className="w-4 h-4" /> },
    { id: 'playground', label: 'Prompt Architect', icon: <Sliders className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 flex h-16 w-full items-center justify-between border-b border-[#303134] bg-[#131314]/90 px-4 backdrop-blur-md">
      {/* Left brand area */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="rounded-lg p-2 text-[#9aa0a6] hover:bg-[#282a2c] hover:text-white transition-colors"
          title="Toggle Navigation Sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div
          className="flex items-center gap-2.5 cursor-pointer group"
          onClick={onGoToLanding}
          title="Return to Gemini Landing Page"
        >
          <div className="relative flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-[#4285F4] via-[#9B72CB] to-[#D96570] p-[1.5px] shadow-lg shadow-[#4285F4]/20">
            <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-[#131314]">
              <Sparkles className="h-4 w-4 text-[#8ab4f8] animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-base font-semibold tracking-tight text-white group-hover:text-[#8ab4f8] transition-colors">
                Gemini
              </span>
              <span className="rounded bg-[#8ab4f8]/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-[#8ab4f8]">
                Studio
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Center Studio Modes Navigation */}
      <nav className="hidden md:flex items-center gap-1 rounded-xl bg-[#1e1f20] p-1 border border-[#303134]">
        {modes.map((mode) => {
          const isActive = currentMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => onSelectMode(mode.id)}
              className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-[#4285f4]/20 via-[#9b72cb]/20 to-[#d96570]/20 text-white border border-[#4285f4]/40 shadow-sm'
                  : 'text-[#9aa0a6] hover:bg-[#282a2c] hover:text-[#e3e3e3]'
              }`}
            >
              <span className={isActive ? 'text-[#8ab4f8]' : 'text-[#9aa0a6]'}>{mode.icon}</span>
              <span>{mode.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Right controls */}
      <div className="flex items-center gap-2.5">
        {/* Model switcher */}
        <div className="relative">
          <button
            onClick={() => setModelDropdownOpen(!modelDropdownOpen)}
            className="flex items-center gap-2 rounded-lg border border-[#303134] bg-[#1e1f20] px-3 py-1.5 text-xs font-medium text-[#e3e3e3] hover:bg-[#282a2c] transition-colors"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping opacity-75" />
            <span className="hidden sm:inline font-mono">
              {AVAILABLE_MODELS.find((m) => m.id === selectedModel)?.name || selectedModel}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-[#9aa0a6]" />
          </button>

          {modelDropdownOpen && (
            <div
              className="absolute right-0 mt-2 w-64 rounded-xl border border-[#3c4043] bg-[#1e1f20] p-1.5 shadow-xl shadow-black/50 z-50 animate-in fade-in zoom-in-95 duration-150"
              onMouseLeave={() => setModelDropdownOpen(false)}
            >
              <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-[#9aa0a6] border-b border-[#303134]">
                Active Free Tier Models
              </div>
              <div className="py-1 space-y-0.5">
                {AVAILABLE_MODELS.map((model) => (
                  <button
                    key={model.id}
                    onClick={() => {
                      onSelectModel(model.id);
                      setModelDropdownOpen(false);
                    }}
                    className={`w-full flex items-center justify-between rounded-lg px-3 py-2 text-left text-xs transition-colors ${
                      selectedModel === model.id
                        ? 'bg-[#8ab4f8]/15 text-[#8ab4f8]'
                        : 'text-[#e3e3e3] hover:bg-[#282a2c]'
                    }`}
                  >
                    <div>
                      <div className="font-medium text-white">{model.name}</div>
                      <div className="text-[11px] text-[#9aa0a6]">{model.tag}</div>
                    </div>
                    {selectedModel === model.id && (
                      <CheckCircle2 className="w-4 h-4 text-[#8ab4f8]" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Delete History Shortcut Button */}
        <button
          onClick={onOpenDeleteHistory}
          className="flex items-center gap-1.5 rounded-lg border border-[#3c4043] bg-[#1e1f20] px-2.5 py-1.5 text-xs text-[#c4c7c5] hover:text-red-400 hover:border-red-500/40 transition-colors"
          title="Delete chat history"
        >
          <Trash2 className="w-3.5 h-3.5 text-red-400" />
          <span className="hidden xl:inline">Delete History</span>
        </button>

        {/* User Account Button or Sign in */}
        {currentUser ? (
          <div className="relative">
            <button
              onClick={() => setUserDropdownOpen(!userDropdownOpen)}
              className="flex items-center gap-2 rounded-full border border-[#3c4043] bg-[#282a2c] p-1 hover:border-[#8ab4f8] transition-colors"
            >
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-tr from-[#4285F4] to-[#9B72CB] text-xs font-bold text-white uppercase">
                {currentUser.name ? currentUser.name[0] : currentUser.email[0]}
              </div>
            </button>

            {userDropdownOpen && (
              <div
                className="absolute right-0 mt-2 w-64 rounded-2xl border border-[#3c4043] bg-[#202124] p-3 shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150"
                onMouseLeave={() => setUserDropdownOpen(false)}
              >
                <div className="border-b border-[#303134] pb-3 mb-2">
                  <div className="font-semibold text-white text-xs truncate capitalize">
                    {currentUser.name}
                  </div>
                  <div className="text-[11px] text-[#9aa0a6] truncate">{currentUser.email}</div>
                  <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-400">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Google Account Linked</span>
                  </div>
                </div>

                <div className="space-y-1 text-xs">
                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onOpenDeleteHistory();
                    }}
                    className="w-full flex items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[#c4c7c5] hover:bg-[#282a2c] hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                    <span>Delete Chat History</span>
                  </button>
                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onGoToLanding();
                    }}
                    className="w-full flex items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[#c4c7c5] hover:bg-[#282a2c] hover:text-white transition-colors"
                  >
                    <Home className="w-4 h-4 text-[#8ab4f8]" />
                    <span>Gemini Home Page</span>
                  </button>
                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onSignOut();
                    }}
                    className="w-full flex items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[#9aa0a6] hover:bg-[#282a2c] hover:text-white transition-colors border-t border-[#303134] pt-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <button
            onClick={onOpenSignIn}
            className="flex items-center gap-1.5 rounded-xl bg-white px-3.5 py-1.5 text-xs font-semibold text-[#1f1f1f] hover:bg-[#f1f3f4] transition-all shadow-sm"
          >
            {/* Google G */}
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span className="hidden sm:inline">Continue with Google</span>
          </button>
        )}
      </div>
    </header>
  );
}
