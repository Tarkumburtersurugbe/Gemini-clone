import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Paperclip,
  Camera,
  Mic,
  Globe,
  Brain,
  X,
  Volume2,
  Copy,
  Check,
  RotateCcw,
  Film,
  FileText,
  Play,
  Pause,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Sliders,
  Image as ImageIcon,
  Loader2,
} from 'lucide-react';
import { ChatMessage, FileAttachment, SampleMediaItem } from '../types';
import { MarkdownRenderer } from '../utils/markdownRenderer';
import { STARTER_PROMPTS } from '../data/samples';
import { fileToBase64 } from '../utils/fileHelpers';

interface ChatWorkspaceProps {
  messages: ChatMessage[];
  onSendMessage: (text: string, files: FileAttachment[], enableSearch: boolean, enableThinking: boolean) => void;
  isLoading: boolean;
  onOpenSampleModal: () => void;
  onOpenCameraModal: () => void;
  onOpenMicModal: () => void;
  pendingAttachments: FileAttachment[];
  onAddAttachment: (attachment: FileAttachment) => void;
  onRemoveAttachment: (id: string) => void;
  selectedModel: string;
}

export function ChatWorkspace({
  messages,
  onSendMessage,
  isLoading,
  onOpenSampleModal,
  onOpenCameraModal,
  onOpenMicModal,
  pendingAttachments,
  onAddAttachment,
  onRemoveAttachment,
  selectedModel,
}: ChatWorkspaceProps) {
  const [inputText, setInputText] = useState('');
  const [enableSearch, setEnableSearch] = useState(false);
  const [enableThinking, setEnableThinking] = useState(false);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [loadingAudioId, setLoadingAudioId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [thinkingExpanded, setThinkingExpanded] = useState<Record<string, boolean>>({});

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Handle textarea autosize
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [inputText]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && pendingAttachments.length === 0) || isLoading) return;

    onSendMessage(inputText.trim(), [...pendingAttachments], enableSearch, enableThinking);
    setInputText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const base64 = await fileToBase64(file);
        let type: 'image' | 'video' | 'audio' | 'document' = 'document';
        if (file.type.startsWith('image/')) type = 'image';
        else if (file.type.startsWith('video/')) type = 'video';
        else if (file.type.startsWith('audio/')) type = 'audio';

        const previewUrl = URL.createObjectURL(file);

        onAddAttachment({
          id: `file-${Date.now()}-${i}`,
          name: file.name,
          mimeType: file.type || 'application/octet-stream',
          base64,
          previewUrl,
          size: file.size,
          type,
        });
      } catch (err) {
        console.error('File load error:', err);
      }
    }
    // reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handlePlayTTS = async (messageId: string, text: string) => {
    if (playingAudioId === messageId && currentAudioRef.current) {
      currentAudioRef.current.pause();
      setPlayingAudioId(null);
      return;
    }

    try {
      setLoadingAudioId(messageId);
      // Clean markdown tags for natural speech
      const cleanText = text.replace(/```[\s\S]*?```/g, 'Code block omitted.').replace(/[#*`_]/g, '');

      const res = await fetch('/api/audio/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: cleanText.slice(0, 1000), // optimal chunk
          voice: 'Kore',
        }),
      });

      const data = await res.json();
      if (data.audioBase64) {
        if (currentAudioRef.current) {
          currentAudioRef.current.pause();
        }
        const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
        currentAudioRef.current = audio;
        audio.play();
        setPlayingAudioId(messageId);
        audio.onended = () => setPlayingAudioId(null);
      }
    } catch (err) {
      console.error('TTS error:', err);
    } finally {
      setLoadingAudioId(null);
    }
  };

  const toggleThinking = (id: string) => {
    setThinkingExpanded((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  return (
    <div className="relative flex flex-1 flex-col h-[calc(100vh-4rem)] bg-[#131314] overflow-hidden">
      {/* Scrollable Message History or Empty State */}
      <div className="flex-1 overflow-y-auto px-4 py-6 md:px-8">
        <div className="mx-auto max-w-4xl space-y-6">
          {messages.length === 0 ? (
            /* Welcome Empty State */
            <div className="py-8 text-center animate-in fade-in duration-300">
              <div className="inline-flex items-center gap-2 rounded-full border border-[#303134] bg-[#1e1f20] px-3.5 py-1.5 text-xs text-[#9aa0a6] mb-6">
                <Sparkles className="h-3.5 w-3.5 text-[#8ab4f8]" />
                <span>Next-Gen Gemini 3.8 Multimodal AI</span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-white mb-3">
                <span className="gemini-gradient-text">Hello, Explorer</span>
              </h1>
              <p className="text-base sm:text-lg text-[#9aa0a6] max-w-xl mx-auto mb-8">
                Generate high-impact content, analyze videos scene-by-scene, inspect images, and synthesize lifelike audio with all Gemini capabilities.
              </p>

              {/* Starter Prompt Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-left">
                {STARTER_PROMPTS.map((starter, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setInputText(starter.prompt);
                      textareaRef.current?.focus();
                    }}
                    className="group relative flex flex-col justify-between rounded-xl border border-[#303134] bg-[#1e1f20]/70 p-4 hover:border-[#8ab4f8]/50 hover:bg-[#1e1f20] transition-all text-left shadow-sm"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="rounded bg-[#8ab4f8]/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-[#8ab4f8]">
                          {starter.category}
                        </span>
                        <Sparkles className="w-3.5 h-3.5 text-[#9aa0a6] group-hover:text-[#8ab4f8] transition-colors" />
                      </div>
                      <h3 className="text-sm font-semibold text-white mb-1 group-hover:text-[#8ab4f8] transition-colors">
                        {starter.title}
                      </h3>
                      <p className="text-xs text-[#9aa0a6] line-clamp-2">
                        {starter.prompt}
                      </p>
                    </div>
                  </button>
                ))}
              </div>

              {/* Instant sample button */}
              <div className="mt-8 flex justify-center">
                <button
                  onClick={onOpenSampleModal}
                  className="inline-flex items-center gap-2 rounded-xl border border-[#3c4043] bg-[#282a2c] px-4 py-2 text-xs font-medium text-white hover:bg-[#37393b] hover:border-[#8ab4f8] transition-colors shadow-sm"
                >
                  <Film className="w-4 h-4 text-[#8ab4f8]" />
                  <span>Explore Preloaded Videos, Charts & Documents</span>
                </button>
              </div>
            </div>
          ) : (
            /* Conversation Messages */
            messages.map((message) => {
              const isUser = message.role === 'user';
              return (
                <div
                  key={message.id}
                  className={`flex gap-3.5 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {/* Model Avatar */}
                  {!isUser && (
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-tr from-[#4285F4] via-[#9B72CB] to-[#D96570] text-white p-[1px] shadow-md shadow-[#4285F4]/20">
                      <div className="flex h-full w-full items-center justify-center rounded-[11px] bg-[#131314]">
                        <Sparkles className="h-4 w-4 text-[#8ab4f8]" />
                      </div>
                    </div>
                  )}

                  {/* Message Bubble */}
                  <div
                    className={`relative max-w-[85%] rounded-2xl p-4 shadow-sm ${
                      isUser
                        ? 'bg-[#282a2c] text-white border border-[#3c4043]'
                        : 'bg-[#1e1f20] text-[#e3e3e3] border border-[#303134]'
                    }`}
                  >
                    {/* Attached files preview */}
                    {message.files && message.files.length > 0 && (
                      <div className="mb-3 flex flex-wrap gap-2">
                        {message.files.map((file) => (
                          <div
                            key={file.id}
                            className="overflow-hidden rounded-lg border border-[#303134] bg-[#131314]"
                          >
                            {file.type === 'image' && (
                              <img
                                src={file.previewUrl}
                                alt={file.name}
                                className="max-h-48 max-w-xs object-cover rounded"
                              />
                            )}
                            {file.type === 'video' && (
                              <video
                                src={file.previewUrl}
                                controls
                                className="max-h-48 max-w-xs rounded"
                              />
                            )}
                            {file.type === 'audio' && (
                              <audio src={file.previewUrl} controls className="h-10 w-60" />
                            )}
                            {file.type === 'document' && (
                              <div className="flex items-center gap-2 p-2.5 text-xs text-[#c4c7c5]">
                                <FileText className="h-4 w-4 text-[#8ab4f8]" />
                                <span className="font-medium truncate max-w-[160px]">{file.name}</span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Thinking Process Accordion */}
                    {message.thinkingProcess && (
                      <div className="mb-3 overflow-hidden rounded-xl border border-[#3c4043] bg-[#131314]/80">
                        <button
                          onClick={() => toggleThinking(message.id)}
                          className="flex w-full items-center justify-between px-3 py-2 text-xs font-medium text-[#8ab4f8] hover:bg-[#282a2c]/50 transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            <Brain className="h-3.5 w-3.5" />
                            <span>Thinking Process (Chain of Thought)</span>
                          </div>
                          {thinkingExpanded[message.id] ? (
                            <ChevronUp className="h-3.5 w-3.5" />
                          ) : (
                            <ChevronDown className="h-3.5 w-3.5" />
                          )}
                        </button>
                        {thinkingExpanded[message.id] && (
                          <div className="border-t border-[#303134] p-3 text-xs text-[#9aa0a6] font-mono leading-relaxed bg-black/30 whitespace-pre-wrap max-h-60 overflow-y-auto">
                            {message.thinkingProcess}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Message Text Content */}
                    {message.content ? (
                      <MarkdownRenderer content={message.content} />
                    ) : message.isStreaming ? (
                      <div className="flex items-center gap-2 text-xs text-[#9aa0a6]">
                        <Loader2 className="w-4 h-4 animate-spin text-[#8ab4f8]" />
                        <span>Gemini is generating response...</span>
                      </div>
                    ) : null}

                    {/* Search Grounding Sources */}
                    {message.groundingMetadata?.groundingChunks &&
                      message.groundingMetadata.groundingChunks.length > 0 && (
                        <div className="mt-4 pt-3 border-t border-[#303134]">
                          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#8ab4f8] mb-2">
                            <Globe className="h-3.5 w-3.5" />
                            <span>Sources & Search Grounding</span>
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {message.groundingMetadata.groundingChunks.map((chunk, idx) => {
                              if (!chunk.web?.uri) return null;
                              return (
                                <a
                                  key={idx}
                                  href={chunk.web.uri}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 rounded-md bg-[#282a2c] px-2 py-1 text-[11px] text-[#c4c7c5] hover:bg-[#37393b] hover:text-[#8ab4f8] transition-colors border border-[#3c4043]"
                                >
                                  <ExternalLink className="h-2.5 w-2.5" />
                                  <span className="truncate max-w-[200px]">
                                    {chunk.web.title || chunk.web.uri}
                                  </span>
                                </a>
                              );
                            })}
                          </div>
                        </div>
                      )}

                    {/* Action Bar for Model Messages */}
                    {!isUser && message.content && (
                      <div className="mt-3 flex items-center gap-2 pt-2 border-t border-[#303134]/50 text-xs text-[#9aa0a6]">
                        <button
                          onClick={() => handlePlayTTS(message.id, message.content)}
                          disabled={loadingAudioId === message.id}
                          className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-[#282a2c] hover:text-white transition-colors"
                          title="Listen with Gemini TTS"
                        >
                          {loadingAudioId === message.id ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin text-[#8ab4f8]" />
                          ) : playingAudioId === message.id ? (
                            <Pause className="h-3.5 w-3.5 text-[#8ab4f8]" />
                          ) : (
                            <Volume2 className="h-3.5 w-3.5" />
                          )}
                          <span>{playingAudioId === message.id ? 'Pause' : 'Listen'}</span>
                        </button>

                        <button
                          onClick={() => handleCopyText(message.id, message.content)}
                          className="flex items-center gap-1 rounded-md px-2 py-1 hover:bg-[#282a2c] hover:text-white transition-colors"
                          title="Copy text"
                        >
                          {copiedId === message.id ? (
                            <Check className="h-3.5 w-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="h-3.5 w-3.5" />
                          )}
                          <span>{copiedId === message.id ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Floating Bottom Input Composer */}
      <div className="p-4 md:px-8 bg-gradient-to-t from-[#131314] via-[#131314] to-transparent">
        <div className="mx-auto max-w-4xl">
          {/* Attachments preview queue */}
          {pendingAttachments.length > 0 && (
            <div className="mb-2 flex flex-wrap gap-2 rounded-xl bg-[#1e1f20] p-2 border border-[#303134]">
              {pendingAttachments.map((file) => (
                <div
                  key={file.id}
                  className="group relative flex items-center gap-2 rounded-lg bg-[#282a2c] px-2.5 py-1.5 text-xs text-white border border-[#3c4043]"
                >
                  {file.type === 'image' && (
                    <img src={file.previewUrl} alt="thumb" className="h-6 w-6 rounded object-cover" />
                  )}
                  {file.type === 'video' && <Film className="h-4 w-4 text-[#8ab4f8]" />}
                  {file.type === 'audio' && <Mic className="h-4 w-4 text-emerald-400" />}
                  {file.type === 'document' && <FileText className="h-4 w-4 text-amber-400" />}
                  <span className="truncate max-w-[140px]">{file.name}</span>
                  <button
                    onClick={() => onRemoveAttachment(file.id)}
                    className="rounded p-0.5 hover:bg-[#37393b] text-[#9aa0a6] hover:text-red-400"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Main Input Box */}
          <div className="relative rounded-2xl border border-[#3c4043] bg-[#1e1f20] shadow-xl focus-within:border-[#8ab4f8] focus-within:ring-1 focus-within:ring-[#8ab4f8]/50 transition-all">
            <textarea
              ref={textareaRef}
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask anything, analyze media, generate ideas or debug code..."
              className="w-full resize-none bg-transparent px-4 pt-3 pb-12 text-sm text-white placeholder-[#9aa0a6] focus:outline-none"
            />

            {/* Input Controls Bar */}
            <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
              {/* Left Attachment & Tool Buttons */}
              <div className="flex items-center gap-1">
                {/* Hidden file input */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  multiple
                  accept="image/*,video/mp4,video/webm,audio/*,.pdf,.txt,.md,.json,.csv"
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="rounded-lg p-2 text-[#9aa0a6] hover:bg-[#282a2c] hover:text-white transition-colors"
                  title="Upload Image, Video, Audio, or File"
                >
                  <Paperclip className="h-4 w-4" />
                </button>

                <button
                  type="button"
                  onClick={onOpenCameraModal}
                  className="rounded-lg p-2 text-[#9aa0a6] hover:bg-[#282a2c] hover:text-white transition-colors"
                  title="Take Photo with Camera"
                >
                  <Camera className="h-4 w-4" />
                </button>

                <button
                  type="button"
                  onClick={onOpenMicModal}
                  className="rounded-lg p-2 text-[#9aa0a6] hover:bg-[#282a2c] hover:text-white transition-colors"
                  title="Record Voice Note"
                >
                  <Mic className="h-4 w-4" />
                </button>

                <button
                  type="button"
                  onClick={onOpenSampleModal}
                  className="rounded-lg p-2 text-[#8ab4f8] hover:bg-[#282a2c] transition-colors"
                  title="Pick from High-Res Samples"
                >
                  <Film className="h-4 w-4" />
                </button>

                <div className="mx-1 h-4 w-[1px] bg-[#303134]" />

                {/* Search Grounding Toggle */}
                <button
                  type="button"
                  onClick={() => setEnableSearch(!enableSearch)}
                  className={`flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium transition-colors ${
                    enableSearch
                      ? 'bg-[#8ab4f8]/20 text-[#8ab4f8] border border-[#8ab4f8]/40'
                      : 'text-[#9aa0a6] hover:bg-[#282a2c] hover:text-white'
                  }`}
                  title="Google Search Grounding (Live Web Data)"
                >
                  <Globe className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Search</span>
                </button>

                {/* Thinking Mode Toggle */}
                <button
                  type="button"
                  onClick={() => setEnableThinking(!enableThinking)}
                  className={`flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium transition-colors ${
                    enableThinking
                      ? 'bg-[#9b72cb]/20 text-[#c58af9] border border-[#9b72cb]/40'
                      : 'text-[#9aa0a6] hover:bg-[#282a2c] hover:text-white'
                  }`}
                  title="Thinking Mode (Deep Reasoning)"
                >
                  <Brain className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Thinking</span>
                </button>
              </div>

              {/* Right Send Button */}
              <button
                type="button"
                onClick={() => handleSubmit()}
                disabled={(!inputText.trim() && pendingAttachments.length === 0) || isLoading}
                className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-[#4285F4] to-[#9B72CB] text-white shadow-md shadow-[#4285F4]/30 hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>

          <div className="mt-2 text-center text-[11px] text-[#9aa0a6]">
            Gemini may display inaccurate info, including about people, so double-check its responses.
          </div>
        </div>
      </div>
    </div>
  );
}
