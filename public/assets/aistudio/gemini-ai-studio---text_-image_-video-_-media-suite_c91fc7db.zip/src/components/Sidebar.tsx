import React from 'react';
import {
  Plus,
  MessageSquare,
  Image as ImageIcon,
  Video,
  Mic,
  Sliders,
  Trash2,
  Sparkles,
  HelpCircle,
  Film,
  Zap,
} from 'lucide-react';
import { ChatSession, StudioMode } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  currentMode: StudioMode;
  onSelectMode: (mode: StudioMode) => void;
  onOpenSampleModal: () => void;
  onOpenDeleteHistory: () => void;
}

export function Sidebar({
  isOpen,
  onClose,
  sessions,
  activeSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  currentMode,
  onSelectMode,
  onOpenSampleModal,
  onOpenDeleteHistory,
}: SidebarProps) {
  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
        />
      )}

      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 flex w-72 flex-col justify-between border-r border-[#303134] bg-[#1e1f20] p-3 transition-transform duration-200 ease-in-out lg:static ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex flex-col gap-3 overflow-hidden">
          {/* New Chat Button */}
          <button
            onClick={() => {
              onNewChat();
              onSelectMode('chat');
            }}
            className="group relative flex w-full items-center justify-between overflow-hidden rounded-xl bg-[#131314] p-3 text-left font-medium text-white shadow-sm border border-[#3c4043] hover:border-[#8ab4f8] transition-all"
          >
            <div className="flex items-center gap-2.5">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-tr from-[#4285F4] to-[#9B72CB] text-white">
                <Plus className="h-4 w-4" />
              </div>
              <span className="text-sm">New Gemini Chat</span>
            </div>
            <Sparkles className="h-4 w-4 text-[#8ab4f8] opacity-70 group-hover:rotate-12 transition-transform" />
          </button>

          {/* Quick Studio Tools */}
          <div className="space-y-1">
            <div className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-[#9aa0a6]">
              Studio Capabilities
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => onSelectMode('imagen')}
                className={`flex items-center gap-2 rounded-lg p-2 text-xs transition-colors border ${
                  currentMode === 'imagen'
                    ? 'border-[#9b72cb] bg-[#9b72cb]/15 text-white'
                    : 'border-[#303134] bg-[#131314]/50 text-[#c4c7c5] hover:bg-[#282a2c]'
                }`}
              >
                <ImageIcon className="h-3.5 w-3.5 text-[#d96570]" />
                <span className="truncate">Imagen 3</span>
              </button>
              <button
                onClick={() => onSelectMode('video')}
                className={`flex items-center gap-2 rounded-lg p-2 text-xs transition-colors border ${
                  currentMode === 'video'
                    ? 'border-[#4285f4] bg-[#4285f4]/15 text-white'
                    : 'border-[#303134] bg-[#131314]/50 text-[#c4c7c5] hover:bg-[#282a2c]'
                }`}
              >
                <Video className="h-3.5 w-3.5 text-[#8ab4f8]" />
                <span className="truncate">Video Lab</span>
              </button>
              <button
                onClick={() => onSelectMode('audio')}
                className={`flex items-center gap-2 rounded-lg p-2 text-xs transition-colors border ${
                  currentMode === 'audio'
                    ? 'border-emerald-500 bg-emerald-500/15 text-white'
                    : 'border-[#303134] bg-[#131314]/50 text-[#c4c7c5] hover:bg-[#282a2c]'
                }`}
              >
                <Mic className="h-3.5 w-3.5 text-emerald-400" />
                <span className="truncate">Voice & TTS</span>
              </button>
              <button
                onClick={() => onSelectMode('playground')}
                className={`flex items-center gap-2 rounded-lg p-2 text-xs transition-colors border ${
                  currentMode === 'playground'
                    ? 'border-[#fbbc04] bg-[#fbbc04]/15 text-white'
                    : 'border-[#303134] bg-[#131314]/50 text-[#c4c7c5] hover:bg-[#282a2c]'
                }`}
              >
                <Sliders className="h-3.5 w-3.5 text-[#fbbc04]" />
                <span className="truncate">Architect</span>
              </button>
            </div>
          </div>

          {/* Sample Explorer Launcher */}
          <button
            onClick={onOpenSampleModal}
            className="flex items-center gap-2.5 rounded-xl border border-dashed border-[#8ab4f8]/40 bg-[#8ab4f8]/10 p-2.5 text-left text-xs font-medium text-[#8ab4f8] hover:bg-[#8ab4f8]/15 transition-colors"
          >
            <Film className="h-4 w-4 shrink-0" />
            <div className="flex-1">
              <div className="font-semibold text-white">Sample Media Showcase</div>
              <div className="text-[11px] text-[#9aa0a6]">Test 4K videos, charts & diagrams</div>
            </div>
            <Zap className="h-3.5 w-3.5 text-amber-400" />
          </button>

          {/* Recent Conversations List */}
          <div className="flex-1 overflow-y-auto pr-1">
            <div className="flex items-center justify-between px-2 py-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#9aa0a6]">
                Recent Conversations
              </span>
              <button
                onClick={onOpenDeleteHistory}
                className="text-[11px] text-[#9aa0a6] hover:text-red-400 flex items-center gap-1 transition-colors"
                title="Manage and delete history"
              >
                <Trash2 className="w-3 h-3 text-red-400" />
                <span>Delete</span>
              </button>
            </div>
            <div className="space-y-1">
              {sessions.map((session) => {
                const isActive = activeSessionId === session.id && currentMode === 'chat';
                return (
                  <div
                    key={session.id}
                    className={`group flex items-center justify-between rounded-lg px-2.5 py-2 text-xs transition-colors ${
                      isActive
                        ? 'bg-[#282a2c] text-white font-medium'
                        : 'text-[#c4c7c5] hover:bg-[#282a2c]/60'
                    }`}
                  >
                    <button
                      onClick={() => {
                        onSelectSession(session.id);
                        onSelectMode('chat');
                      }}
                      className="flex flex-1 items-center gap-2 truncate text-left"
                    >
                      <MessageSquare className="h-3.5 w-3.5 shrink-0 text-[#9aa0a6] group-hover:text-[#8ab4f8]" />
                      <span className="truncate">{session.title}</span>
                    </button>
                    {sessions.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteSession(session.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 p-1 text-[#9aa0a6] hover:text-red-400 transition-opacity"
                        title="Delete chat"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="border-t border-[#303134] pt-3 text-xs text-[#9aa0a6]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <HelpCircle className="h-3.5 w-3.5" />
              <span>Gemini 3.8 Flash & Argon</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono">v2.4.0 SDK</span>
          </div>
        </div>
      </aside>
    </>
  );
}
