import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { ChatWorkspace } from './components/ChatWorkspace';
import { ImagenStudio } from './components/ImagenStudio';
import { VideoLab } from './components/VideoLab';
import { AudioStudio } from './components/AudioStudio';
import { Playground } from './components/Playground';
import { SampleMediaModal } from './components/SampleMediaModal';
import { MediaCaptureModal } from './components/MediaCaptureModal';
import { LandingPage } from './components/LandingPage';
import { GoogleSignInModal } from './components/GoogleSignInModal';
import { DeleteHistoryModal } from './components/DeleteHistoryModal';
import {
  StudioMode,
  ChatSession,
  ChatMessage,
  FileAttachment,
  SampleMediaItem,
  UserProfile,
} from './types';
import { urlToBase64 } from './utils/fileHelpers';

const STORAGE_KEY = 'gemini_studio_sessions_v1';
const USER_STORAGE_KEY = 'gemini_studio_user_profile_v1';

export default function App() {
  const [view, setView] = useState<'landing' | 'studio'>('landing');
  const [currentMode, setCurrentMode] = useState<StudioMode>('chat');
  const [selectedModel, setSelectedModel] = useState<string>('gemini-3.5-flash-lite');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // User Authentication
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const savedUser = localStorage.getItem(USER_STORAGE_KEY);
      if (savedUser) return JSON.parse(savedUser);
    } catch (e) {}
    return null;
  });

  // Modals
  const [isSignInModalOpen, setIsSignInModalOpen] = useState(false);
  const [isDeleteHistoryModalOpen, setIsDeleteHistoryModalOpen] = useState(false);
  const [isSampleModalOpen, setIsSampleModalOpen] = useState(false);
  const [mediaCaptureModal, setMediaCaptureModal] = useState<{
    isOpen: boolean;
    type: 'camera' | 'microphone';
  }>({ isOpen: false, type: 'camera' });

  // Attachments pending in chat input composer
  const [pendingAttachments, setPendingAttachments] = useState<FileAttachment[]>([]);
  const [videoLabInitial, setVideoLabInitial] = useState<{ url?: string; title?: string }>({});

  // Chat sessions
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to parse saved sessions:', e);
    }
    const initialSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'Multimodal Chat',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: 'gemini-3.5-flash-lite',
      temperature: 0.7,
      topP: 0.95,
      enableSearch: false,
    };
    return [initialSession];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => sessions[0]?.id || '');
  const [isLoading, setIsLoading] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    } catch (e) {
      console.error('Storage save error:', e);
    }
  }, [sessions]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(USER_STORAGE_KEY);
      }
    } catch (e) {}
  }, [currentUser]);

  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0];

  const handleSignIn = (profile: UserProfile) => {
    setCurrentUser(profile);
    setIsSignInModalOpen(false);
    setView('studio');
  };

  const handleSignOut = () => {
    setCurrentUser(null);
    setView('landing');
  };

  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'New Chat',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: selectedModel,
      temperature: 0.7,
      topP: 0.95,
      enableSearch: false,
    };
    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    setPendingAttachments([]);
  };

  // Delete History Handlers
  const handleDeleteSession = (id: string) => {
    const remaining = sessions.filter((s) => s.id !== id);
    if (remaining.length === 0) {
      const freshSession: ChatSession = {
        id: `session-${Date.now()}`,
        title: 'New Chat',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
        model: selectedModel,
        temperature: 0.7,
        topP: 0.95,
        enableSearch: false,
      };
      setSessions([freshSession]);
      setActiveSessionId(freshSession.id);
    } else {
      setSessions(remaining);
      if (activeSessionId === id) {
        setActiveSessionId(remaining[0].id);
      }
    }
  };

  const handleDeleteAllSessions = () => {
    const freshSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'New Chat',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: selectedModel,
      temperature: 0.7,
      topP: 0.95,
      enableSearch: false,
    };
    setSessions([freshSession]);
    setActiveSessionId(freshSession.id);
    setPendingAttachments([]);
  };

  const handleDeleteRecent = (hours: number) => {
    const cutoff = Date.now() - hours * 60 * 60 * 1000;
    const remaining = sessions.filter((s) => s.updatedAt < cutoff);
    if (remaining.length === 0) {
      handleDeleteAllSessions();
    } else {
      setSessions(remaining);
      setActiveSessionId(remaining[0].id);
    }
  };

  const handleSendMessage = async (
    text: string,
    files: FileAttachment[],
    enableSearch: boolean,
    enableThinking: boolean
  ) => {
    if ((!text.trim() && files.length === 0) || isLoading) return;

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      files,
    };

    const modelMessageId = `msg-${Date.now()}-model`;
    const modelMessage: ChatMessage = {
      id: modelMessageId,
      role: 'model',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    const updatedTitle =
      activeSession.messages.length === 0 && text.trim()
        ? text.slice(0, 32).trim() + (text.length > 32 ? '...' : '')
        : activeSession.title;

    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            title: updatedTitle,
            updatedAt: Date.now(),
            messages: [...s.messages, userMessage, modelMessage],
          };
        }
        return s;
      })
    );

    setPendingAttachments([]);
    setIsLoading(true);

    try {
      const history = activeSession.messages.map((m) => ({
        role: m.role,
        content: m.content,
        parts: [
          ...(m.files || []).map((f) => ({
            inlineData: { mimeType: f.mimeType, data: f.base64 },
          })),
          ...(m.content ? [{ text: m.content }] : []),
        ],
      }));

      const res = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          history,
          model: selectedModel,
          enableSearch,
          thinkingLevel: enableThinking ? 'HIGH' : undefined,
          files: files.map((f) => ({
            mimeType: f.mimeType,
            base64: f.base64,
          })),
        }),
      });

      if (!res.ok) {
        throw new Error(`HTTP error ${res.status}`);
      }

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let accumulatedThought = '';
      let groundingMetadata: any = null;

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const dataStr = line.slice(6).trim();
              if (dataStr === '[DONE]') break;

              try {
                const parsed = JSON.parse(dataStr);
                if (parsed.error) {
                  throw new Error(parsed.error);
                }
                if (parsed.text) {
                  accumulatedText += parsed.text;
                }
                if (parsed.thought) {
                  accumulatedThought += parsed.thought;
                }
                if (parsed.groundingMetadata) {
                  groundingMetadata = parsed.groundingMetadata;
                }

                setSessions((prev) =>
                  prev.map((s) => {
                    if (s.id === activeSessionId) {
                      return {
                        ...s,
                        messages: s.messages.map((m) => {
                          if (m.id === modelMessageId) {
                            return {
                              ...m,
                              content: accumulatedText,
                              thinkingProcess: accumulatedThought || undefined,
                              groundingMetadata: groundingMetadata || undefined,
                              isStreaming: true,
                            };
                          }
                          return m;
                        }),
                      };
                    }
                    return s;
                  })
                );
              } catch (e) {}
            }
          }
        }
      }

      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: s.messages.map((m) => {
                if (m.id === modelMessageId) {
                  return {
                    ...m,
                    content: accumulatedText,
                    thinkingProcess: accumulatedThought || undefined,
                    groundingMetadata: groundingMetadata || undefined,
                    isStreaming: false,
                  };
                }
                return m;
              }),
            };
          }
          return s;
        })
      );
    } catch (err: any) {
      console.error('Chat error:', err);
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: s.messages.map((m) => {
                if (m.id === modelMessageId) {
                  return {
                    ...m,
                    content:
                      m.content ||
                      `Error: ${err.message || 'Check connection and try again.'}`,
                    isStreaming: false,
                    error: err.message,
                  };
                }
                return m;
              }),
            };
          }
          return s;
        })
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectSample = async (sample: SampleMediaItem, target: 'chat' | 'video') => {
    if (target === 'video') {
      setVideoLabInitial({ url: sample.url, title: sample.title });
      setCurrentMode('video');
      setView('studio');
    } else {
      try {
        const { base64, mimeType } = await urlToBase64(sample.url);
        const attachment: FileAttachment = {
          id: `sample-${Date.now()}`,
          name: `${sample.title.toLowerCase().replace(/\s+/g, '-')}.${mimeType.includes('png') ? 'png' : 'jpg'}`,
          mimeType,
          base64,
          previewUrl: sample.url,
          size: Math.round(base64.length * 0.75),
          type: sample.type,
        };
        setPendingAttachments((prev) => [...prev, attachment]);
        setCurrentMode('chat');
        setView('studio');
      } catch (err) {
        console.error('Failed to load sample into chat:', err);
      }
    }
  };

  const handleSendToChatFromOtherModes = (text: string, files: FileAttachment[]) => {
    setCurrentMode('chat');
    handleSendMessage(text, files, false, false);
  };

  // If on Landing Page, render full Gemini landing page
  if (view === 'landing') {
    return (
      <>
        <LandingPage
          onContinueWithGoogle={() => setIsSignInModalOpen(true)}
          onEnterStudio={() => setView('studio')}
          currentUser={currentUser}
          onSignOut={handleSignOut}
          onOpenDeleteHistory={() => setIsDeleteHistoryModalOpen(true)}
        />

        <GoogleSignInModal
          isOpen={isSignInModalOpen}
          onClose={() => setIsSignInModalOpen(false)}
          onSignIn={handleSignIn}
        />

        <DeleteHistoryModal
          isOpen={isDeleteHistoryModalOpen}
          onClose={() => setIsDeleteHistoryModalOpen(false)}
          sessions={sessions}
          onDeleteSession={handleDeleteSession}
          onDeleteAllSessions={handleDeleteAllSessions}
          onDeleteRecent={handleDeleteRecent}
        />
      </>
    );
  }

  // Gemini Studio Workspace View
  return (
    <div className="flex h-screen w-screen flex-col bg-[#131314] text-[#e3e3e3] overflow-hidden">
      {/* Top Navigation */}
      <Navbar
        currentMode={currentMode}
        onSelectMode={(mode) => setCurrentMode(mode)}
        selectedModel={selectedModel}
        onSelectModel={(model) => setSelectedModel(model)}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
        currentUser={currentUser}
        onOpenSignIn={() => setIsSignInModalOpen(true)}
        onSignOut={handleSignOut}
        onOpenDeleteHistory={() => setIsDeleteHistoryModalOpen(true)}
        onGoToLanding={() => setView('landing')}
      />

      {/* Main Body */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Left Sidebar */}
        <Sidebar
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          sessions={sessions}
          activeSessionId={activeSessionId}
          onSelectSession={(id) => setActiveSessionId(id)}
          onNewChat={handleNewChat}
          onDeleteSession={handleDeleteSession}
          currentMode={currentMode}
          onSelectMode={(mode) => {
            setCurrentMode(mode);
            setIsSidebarOpen(false);
          }}
          onOpenSampleModal={() => setIsSampleModalOpen(true)}
          onOpenDeleteHistory={() => setIsDeleteHistoryModalOpen(true)}
        />

        {/* Studio Center Workspace */}
        <main className="flex flex-1 flex-col overflow-hidden">
          {currentMode === 'chat' && (
            <ChatWorkspace
              messages={activeSession.messages}
              onSendMessage={handleSendMessage}
              isLoading={isLoading}
              onOpenSampleModal={() => setIsSampleModalOpen(true)}
              onOpenCameraModal={() =>
                setMediaCaptureModal({ isOpen: true, type: 'camera' })
              }
              onOpenMicModal={() =>
                setMediaCaptureModal({ isOpen: true, type: 'microphone' })
              }
              pendingAttachments={pendingAttachments}
              onAddAttachment={(att) => setPendingAttachments((prev) => [...prev, att])}
              onRemoveAttachment={(id) =>
                setPendingAttachments((prev) => prev.filter((a) => a.id !== id))
              }
              selectedModel={selectedModel}
            />
          )}

          {currentMode === 'imagen' && (
            <ImagenStudio onSendToChat={handleSendToChatFromOtherModes} />
          )}

          {currentMode === 'video' && (
            <VideoLab
              initialVideoUrl={videoLabInitial.url}
              initialVideoTitle={videoLabInitial.title}
            />
          )}

          {currentMode === 'audio' && <AudioStudio />}

          {currentMode === 'playground' && <Playground />}
        </main>
      </div>

      {/* Google Sign In Modal */}
      <GoogleSignInModal
        isOpen={isSignInModalOpen}
        onClose={() => setIsSignInModalOpen(false)}
        onSignIn={handleSignIn}
      />

      {/* Delete History Modal */}
      <DeleteHistoryModal
        isOpen={isDeleteHistoryModalOpen}
        onClose={() => setIsDeleteHistoryModalOpen(false)}
        sessions={sessions}
        onDeleteSession={handleDeleteSession}
        onDeleteAllSessions={handleDeleteAllSessions}
        onDeleteRecent={handleDeleteRecent}
      />

      {/* Sample Media Modal */}
      <SampleMediaModal
        isOpen={isSampleModalOpen}
        onClose={() => setIsSampleModalOpen(false)}
        onSelectSample={handleSelectSample}
      />

      {/* Camera / Microphone Capture Modal */}
      <MediaCaptureModal
        isOpen={mediaCaptureModal.isOpen}
        type={mediaCaptureModal.type}
        onClose={() =>
          setMediaCaptureModal((prev) => ({ ...prev, isOpen: false }))
        }
        onCapture={(att) => setPendingAttachments((prev) => [...prev, att])}
      />
    </div>
  );
}
